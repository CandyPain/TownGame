﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TownGame.Buildings
{
    internal class Coordinate
    {
        int x {  get; set; }
        int y { get; set; }
    }
}
