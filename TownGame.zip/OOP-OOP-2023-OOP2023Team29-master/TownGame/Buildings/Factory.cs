﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TownGame.Commands;
using TownGame.Resources;

namespace TownGame.Buildings
{
    internal class Factory : building
    {
        int number_of_works { get; }
        int procent_broken { get; set; }
        int max_workers { get; }
        public Factory() //НЕ ГОТОВО
        {
            commands.Add(new Produce());
            Price = new ListResources();
            Price.ListAdd(new MetalRes(5, 6));
            storage = new Storage();
            storage.ListMaxAdd(new MetalRes(20, 6));
            storage.ListMaxAdd(new TreeRes(5, 2));
            max_workers = 100;
            procent_broken = 0;
            number_of_works = 10;
        }
        public int  Get_Number_of_works()
        {
            return number_of_works;
        }
        public int Get_Procent_broken()
        {
           return procent_broken;
        }
    }
}
