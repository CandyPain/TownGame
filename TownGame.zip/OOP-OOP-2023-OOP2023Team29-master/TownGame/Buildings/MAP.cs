﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TownGame.Resources;

namespace TownGame.Buildings
{
    internal class MAP
    {
        //private List<building> ListBuildings = new List<building>();
        private building[,] buildingsArray = new building[6, 7];
        private PictureBox[,] pictureBoxes = new PictureBox[6,7];
        public PictureBox getPictureBox(int i,int j)
        {
            return pictureBoxes[i,j];
        }
        public void AddBuilding(building building,ListResources listResources,int i, int j)
        {
            if(building.Can_build(listResources))
            {
                buildingsArray[i,j] = building;
                Type buildingType = building.GetType();
                if (buildingType == typeof(Factory))
                {
                    pictureBoxes[i, j].Image = Image.FromFile("pictures//банк.png");
                }
            }

        }
        public MAP()
        {
            for (int i = 0; i < 6; ++i)
            {
                for(int j = 0; j < 7;++j)
                {
                    pictureBoxes[i, j] = new PictureBox();
                    pictureBoxes[i,j].SizeMode = PictureBoxSizeMode.StretchImage;
                    pictureBoxes[i, j].Image = Image.FromFile("pictures//пустота.png");
                }
            }
        }
    }
}
