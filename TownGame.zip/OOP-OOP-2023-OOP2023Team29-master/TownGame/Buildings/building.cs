﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TownGame.Commands;
using TownGame.Resources;

namespace TownGame.Buildings
{
    abstract class building
    {
        protected List<Command> commands;
        protected ListResources Price { get; set; }
        protected Storage storage { get; set; }
        protected int Need_Salary { get; set; }
        protected Coordinate coordinate { get; set; }
        public bool Can_build(ListResources lst)
        {
            return true; //сделать проверку
        }
        public Storage GetStorage()
        {
            return storage;
        }

    }
}
