﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TownGame.Resources
{
    internal class TreeRes:Resource
    {
        public TreeRes(int count, int weight) { this.count = count; this.weight = weight; }
    }
}
