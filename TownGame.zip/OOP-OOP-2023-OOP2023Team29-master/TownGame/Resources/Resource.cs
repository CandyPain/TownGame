﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TownGame.Resources
{
    internal abstract class Resource
    {
        protected int count { get; set; }
        protected int weight { get; set; }
        public int Count  
        {
            get { return count; }
            set { count = value; }
        }
        public int Weight  
        {
            get { return weight; }
        }
    }
}
