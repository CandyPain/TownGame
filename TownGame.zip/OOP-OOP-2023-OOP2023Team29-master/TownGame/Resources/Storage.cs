﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TownGame.Resources
{
    internal class Storage
    {
        ListResources ListRes = new ListResources();
        ListResources ListMax = new ListResources();
        public void ListMaxAdd(Resource res)
        {
            ListMax.ListAdd(res);
        }
        public void ListResAdd(Resource res)
        {
            ListRes.ListAdd(res);
        }
        public bool CanAdd(Resource res)
        {
            if((ListRes.GetResources(res)?.Count ?? 0) + res.Count <= (ListMax.GetResources(res)?.Count ?? 0)) { return true; }
            else { return false; }
        }
    }
}
