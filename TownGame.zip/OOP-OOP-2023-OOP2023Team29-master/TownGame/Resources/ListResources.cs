﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TownGame.Resources
{
    class ListResources
    {
        List<Resource> ListRes = new List<Resource>();
        public void ListAdd(Resource resource)
        {
            if (resource is MetalRes);
            int index = ListRes.FindIndex(r => r is MetalRes);
            if(index != -1) { ListRes[index].Count += resource.Count; }
            else {  ListRes.Add(resource); }           
        }
        public Resource GetResources(Resource res)
        {
            if(res is MetalRes)
            {
                foreach (Resource resource in ListRes) 
                {
                    if(resource is MetalRes)
                    {
                        return resource;
                    }
                }
            }
            return null;
        }
    }
}
