﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TownGame.Buildings;
using TownGame.Resources;

namespace TownGame.Commands
{
    internal class Produce :Command
    {
        protected override void Execute(object[] args)
        {
            building build = (building)args[0];
            Resource res = (Resource)args[1];
            if(build is Factory)
            {
                Factory factory = (Factory)build;
                int Number_or_works = factory.Get_Number_of_works();
                int Procent_broken =factory.Get_Procent_broken();
                res.Count += Number_or_works / 5 - Procent_broken / 5;
                //формулу доделать
                produce(res, factory);
            }
        }
        public void produce(Resource resource, Buildings.building building)
        {
            if(building.GetStorage().CanAdd(resource)) { building.GetStorage().ListResAdd(resource); }
        }
    }
}
