﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TownGame.Buildings;
using TownGame.Resources;

namespace TownGame
{
    public partial class Form1 : Form
    {
        private int selectedRow = -1;
        private int selectedColumn = -1;
        TownGame.Buildings.MAP Map = new Buildings.MAP();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*
            PictureBox pictureBox = new PictureBox();
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Image = Image.FromFile("pictures//банк.png");
            Table.Controls.Add(pictureBox,0,1);
            */
            for(int i = 0;i<6;i++)
            {
                for(int j = 0;j<7;++j)
                {
                    Table.Controls.Add(Map.getPictureBox(i,j), j, i);
                    Map.getPictureBox(i,j).Click += PictureBox_Click;
                }
            }
        }
        private void PictureBox_Click(object sender, EventArgs e)
        {
            PictureBox pictureBox = (PictureBox)sender;
            selectedRow = Table.GetRow(pictureBox);
            selectedColumn = Table.GetColumn(pictureBox);
            Table.Refresh();
        }

        private void Add_Factory_Click(object sender, EventArgs e)
        {
            Factory fac = new Factory();
            ListResources lst = new ListResources(); //затычка для проверки работоспособности
            Map.AddBuilding(fac, lst,selectedRow,selectedColumn);
        }

        private void Table_CellPaint(object sender, TableLayoutCellPaintEventArgs e)
        {
            if (e.Row == selectedRow && e.Column == selectedColumn)
            {
                // Изменяем свойства границ выбранной ячейки
                using (Pen pen = new Pen(Color.Black, 6))
                {
                    e.Graphics.DrawRectangle(pen, e.CellBounds);
                }
            }
        }

        private void Table_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
