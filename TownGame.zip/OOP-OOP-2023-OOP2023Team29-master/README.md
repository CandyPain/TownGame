https://app.diagrams.net/#G1ZIC4oax9SgRrQ6sGbHJqJD5ycFkOjUCe
 Ссылка на картинки: https://drive.google.com/file/d/1P3xonbcxxu7YTR-nD4s0uOAllwOUtk0a/view?usp=sharing
 финальный проект лежит в ветке End
